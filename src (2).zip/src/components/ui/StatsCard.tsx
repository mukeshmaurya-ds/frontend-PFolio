type Props = {
  value: string;
  label: string;
};

export default function StatsCard({
  value,
  label,
}: Props) {
  return (
    <div
      className="
      glass
      hover-lift
      rounded-2xl
      px-8
      py-6
      text-center
      "
    >
      <h3 className="text-3xl font-bold text-cyan-400">
        {value}
      </h3>

      <p className="mt-2 text-sm text-slate-400">
        {label}
      </p>
    </div>
  );
}