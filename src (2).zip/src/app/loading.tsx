export default function Loading() {
  return (
    <main
      className="
      flex
      min-h-screen
      items-center
      justify-center
      "
    >
      <div
        className="
        h-16
        w-16
        animate-spin
        rounded-full
        border-4
        border-cyan-500
        border-t-transparent
        "
      />
    </main>
  );
}