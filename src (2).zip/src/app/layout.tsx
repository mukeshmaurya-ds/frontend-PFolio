import type { Metadata } from "next";
import { Geist } from "next/font/google";
import BackgroundEffects from "@/components/effects/BackgroundEffects";
import "./globals.css";

const geist = Geist({
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "NextFolio Pro",
  description: "Production Ready Developer Portfolio",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className={geist.className}>
        <BackgroundEffects/>
        {children}
      </body>
    </html>
  );
}